# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['elordenador_lib']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'elordenador-lib',
    'version': '0.1.1',
    'description': "elordenador's libraries",
    'long_description': None,
    'author': 'Daniel',
    'author_email': 'danilacasito8@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
